from setuptools import setup, find_packages

setup(
    name="gridworld-env",
    version="1.0.0",
    description="Gymnasium environment for reward-misspecification research (GridWorld)",
    packages=find_packages(),
    python_requires=">=3.9",
    install_requires=[
        "gymnasium>=0.29.0",
        "numpy>=1.26.0",
    ],
    extras_require={
        "llm": [
            "google-genai>=0.7.0",
            "pydantic>=2.6.0",
            "python-dotenv>=1.0.1",
            "pandas>=2.2.0",
            "tqdm>=4.66.0",
        ],
        "sb3": ["stable-baselines3>=2.3.0"],
    },
)
