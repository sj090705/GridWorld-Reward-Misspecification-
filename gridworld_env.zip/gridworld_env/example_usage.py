"""
example_usage.py — demonstrates the standardised environment.

Run from the gridworld_env/ directory:
    python example_usage.py
"""

from __future__ import annotations

import sys
import os

# Allow running without pip install (add parent to path)
sys.path.insert(0, os.path.dirname(__file__))

import numpy as np
import gymnasium as gym

# Registering is done by importing the package
import gridworld_env                   # noqa: F401 — side-effect: gym.register


# ─────────────────────────────────────────────────────────────────────────────
# 1. Basic gym.make usage
# ─────────────────────────────────────────────────────────────────────────────
def demo_basic():
    print("=" * 60)
    print("1. Basic gym.make usage")
    print("=" * 60)

    env = gym.make("RewardMisspecGridWorld-v0", reward_mode="true", render_mode="ansi")
    obs, info = env.reset(seed=42)

    print(f"Observation shape : {obs.shape}  dtype={obs.dtype}")
    print(f"Action space      : {env.action_space}")
    print(f"Reward mode       : {info['reward_mode']}")
    print()
    print(env.render())
    print()

    total_reward = 0.0
    for _ in range(info["max_steps"]):
        action = env.action_space.sample()
        obs, reward, terminated, truncated, info = env.step(action)
        total_reward += reward
        if terminated or truncated:
            break

    print(f"Episode done | steps={info['t']} | total_reward={total_reward:.3f} | reached_goal={info.get('at_goal', False)}")
    env.close()


# ─────────────────────────────────────────────────────────────────────────────
# 2. Direct class instantiation with all reward modes
# ─────────────────────────────────────────────────────────────────────────────
def demo_all_modes():
    print("\n" + "=" * 60)
    print("2. All reward modes — random policy")
    print("=" * 60)

    from gridworld_env.env import RewardMisspecGridWorldEnv, REWARD_MODES

    for mode in REWARD_MODES:
        env = RewardMisspecGridWorldEnv(reward_mode=mode, max_steps=30)
        obs, info = env.reset(seed=7)
        total_obs = 0.0
        total_true = 0.0
        steps = 0
        for _ in range(30):
            a = env.action_space.sample()
            obs, r, terminated, truncated, info = env.step(a)
            total_obs  += r
            total_true += info["reward_true"]
            steps += 1
            if terminated or truncated:
                break
        reached = info.get("at_goal", False)
        print(
            f"  mode={mode:<12}  steps={steps:2d}  "
            f"R_obs={total_obs:+6.2f}  R_true={total_true:+6.2f}  "
            f"reached_goal={reached}"
        )
        env.close()


# ─────────────────────────────────────────────────────────────────────────────
# 3. Changing reward_mode per episode via options (no re-instantiation needed)
# ─────────────────────────────────────────────────────────────────────────────
def demo_options_reset():
    print("\n" + "=" * 60)
    print("3. Switching reward_mode per episode via reset(options=…)")
    print("=" * 60)

    from gridworld_env.env import RewardMisspecGridWorldEnv, REWARD_MODES

    env = RewardMisspecGridWorldEnv(reward_mode="true")
    for ep, mode in enumerate(REWARD_MODES):
        obs, info = env.reset(seed=100 + ep, options={"reward_mode": mode})
        print(f"  Episode {ep}  mode={info['reward_mode']:<12}  obs={obs[:3].round(3)}")
    env.close()


# ─────────────────────────────────────────────────────────────────────────────
# 4. Observation vector anatomy
# ─────────────────────────────────────────────────────────────────────────────
def demo_obs_anatomy():
    print("\n" + "=" * 60)
    print("4. Observation vector anatomy")
    print("=" * 60)

    from gridworld_env.env import RewardMisspecGridWorldEnv

    env = RewardMisspecGridWorldEnv(reward_mode="proxy")
    obs, _ = env.reset(seed=0)

    labels = [
        "row (norm)",
        "col (norm)",
        "d_goal (norm)",
        "d_coin (norm)",
        "coin_collected",
        "on_proxy",
        "on_misleading",
        "steps_remaining",
        "reward_mode_idx",
        "prev_reward_obs",
    ]
    for name, val in zip(labels, obs):
        print(f"  {name:<22} = {val:+.4f}")
    env.close()


# ─────────────────────────────────────────────────────────────────────────────
# 5. Grid array and ASCII render
# ─────────────────────────────────────────────────────────────────────────────
def demo_grid_array():
    print("\n" + "=" * 60)
    print("5. Grid array and ASCII render")
    print("=" * 60)

    from gridworld_env.env import RewardMisspecGridWorldEnv

    env = RewardMisspecGridWorldEnv(render_mode="ansi", reward_mode="true")
    obs, info = env.reset(seed=1)

    print("ASCII map (render_mode='ansi'):")
    print(env.render())
    print()
    print("grid_array (int8, tile codes):")
    print(info["grid_array"])
    env.close()


# ─────────────────────────────────────────────────────────────────────────────
# 6. gymnasium.utils.env_checker — conformance check
# ─────────────────────────────────────────────────────────────────────────────
def demo_env_checker():
    print("\n" + "=" * 60)
    print("6. gymnasium env_checker conformance test")
    print("=" * 60)
    try:
        from gymnasium.utils.env_checker import check_env
        from gridworld_env.env import RewardMisspecGridWorldEnv

        env = RewardMisspecGridWorldEnv(reward_mode="true")
        check_env(env, warn=True)
        print("  ✓  All gymnasium conformance checks passed.")
        env.close()
    except ImportError:
        print("  (gym checker not available in this gymnasium version)")


# ─────────────────────────────────────────────────────────────────────────────
if __name__ == "__main__":
    demo_basic()
    demo_all_modes()
    demo_options_reset()
    demo_obs_anatomy()
    demo_grid_array()
    demo_env_checker()
